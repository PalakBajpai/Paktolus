/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int main()
int a;
int b;
int c;
cin>>a>>b;
for(int i=a;i<=b;i++)
{
    int c=a^2+b^2;
    if(c==z^2)
    {
        cout<<a<<b<<z;
    }
}
return 0;
}

